<?php

namespace App\Http\Controllers;

use App\Models\InventoryItem;
use App\Http\Controllers\Controller;

class InventoryController extends Controller
{
    public function index()
    {
        $items = InventoryItem::all();

        return view('inventory.index', compact('items'));
    }

    public function show(InventoryItem $item)
    {
        return view('inventory.show', compact('item'));
    }
}
