<?php

namespace App\Filament\Resources\RentalItemResource\Pages;

use App\Filament\Resources\RentalItemResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRentalItem extends CreateRecord
{
    protected static string $resource = RentalItemResource::class;
}
