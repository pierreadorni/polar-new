<div <?php echo e($attributes->merge($getExtraAttributes())->class(['filament-forms-builder-component-block py-8'])); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/forms/resources/views/components/builder/block.blade.php ENDPATH**/ ?>