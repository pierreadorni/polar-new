<div <?php echo e($attributes->class([
    'filament-global-search-no-results-message px-6 py-4',
    'dark:text-gray-200' => config('filament.dark_mode'),
])); ?>>
    <?php echo e(__('filament::global-search.no_results_message')); ?>

</div>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/filament/resources/views/components/global-search/no-results-message.blade.php ENDPATH**/ ?>