<h2 <?php echo e($attributes->class(['filament-tables-header-heading text-xl font-bold tracking-tight'])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/tables/resources/views/components/header/heading.blade.php ENDPATH**/ ?>