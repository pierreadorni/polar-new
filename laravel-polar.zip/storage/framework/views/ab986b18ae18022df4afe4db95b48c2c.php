
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/filament/resources/views/components/layouts/app/sidebar/footer.blade.php ENDPATH**/ ?>