<?php
    /** @deprecated */
?>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/filament/resources/views/components/notification-manager.blade.php ENDPATH**/ ?>