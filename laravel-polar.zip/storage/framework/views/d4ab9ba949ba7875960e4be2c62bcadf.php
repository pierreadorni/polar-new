<h1 <?php echo e($attributes->class(['filament-header-heading text-2xl font-bold tracking-tight'])); ?>>
    <?php echo e($slot); ?>

</h1>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/filament/resources/views/components/header/heading.blade.php ENDPATH**/ ?>