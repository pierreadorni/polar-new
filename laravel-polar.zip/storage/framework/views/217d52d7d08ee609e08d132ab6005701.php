<p <?php echo e($attributes->class(['filament-header-subheading max-w-2xl tracking-tight text-gray-500'])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/filament/resources/views/components/header/subheading.blade.php ENDPATH**/ ?>