<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/forms/resources/views/components/group.blade.php ENDPATH**/ ?>