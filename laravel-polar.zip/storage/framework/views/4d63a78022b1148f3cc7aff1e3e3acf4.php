<?php echo e(currency($currency)); ?>

<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/akaunting/laravel-money/resources/views/components/currency.blade.php ENDPATH**/ ?>