<h2 <?php echo e($attributes->class(['text-xl font-semibold tracking-tight filament-card-heading'])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/filament/resources/views/components/card/heading.blade.php ENDPATH**/ ?>