<p <?php echo e($attributes->class(['filament-tables-header-description'])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/filament/tables/resources/views/components/header/description.blade.php ENDPATH**/ ?>