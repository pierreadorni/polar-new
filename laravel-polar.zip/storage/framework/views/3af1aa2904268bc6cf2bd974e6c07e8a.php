<div class="flex items-center gap-3">
    <img src="<?php echo e(asset('/images/polar.png')); ?>" alt="Logo" class="h-10">
    <h3 class="text-2xl">Le Polar</h3>
</div>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/resources/views/vendor/filament/components/brand.blade.php ENDPATH**/ ?>