<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet">

    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>
<body class="antialiased h-screen selection:bg-red-500 selection:text-white">
<header class="p-6 fixed top-0 left-0 w-full bg-white h-20 transition-all">
    <ul class="flex items-center justify-center gap-6 h-full">
        <li>
            <a class="" href="/">
                <img src="/images/polar-with-name.svg" alt="polar logo" class="w-24"/>
            </a>
        </li>
        <li>
            <a href="/" class="text-primary font-semibold">
                Accueil
            </a>
        </li>
        <li>
            <a href="/#about" class="text-secondary font-semibold">
                A propos
            </a>
        </li>
        <li>
            <a href="#contact" class="text-secondary font-semibold">
                Contact
            </a>
        </li>
        <li>
            <a href="/hours" class="text-secondary font-semibold">
                Horaires
            </a>
        </li>
        <li>
            <a href="/team" class="text-secondary font-semibold">
                L'équipe
            </a>
        </li>
        <li>
            <a href="/products" class="text-secondary font-semibold">
                Produits
            </a>
        </li>
        <li>
            <a href="/services" class="text-secondary font-semibold">
                Services
            </a>
        </li>
        <li>
            <a href="/admin" class="bg-primary text-white font-medium rounded-lg px-3 py-2 hover:bg-red-900 transition">
                Connexion Admin
            </a>
        </li>
    </ul>
    <div class="fixed top-20 left-0 w-full bg-primary text-white text-center py-1">
        Petite information de la semaine
    </div>
</header>
<?php echo e($slot); ?>

<footer class="h-48 bg-primary py-6 text-white" id="contact">
    <h3 class="text-2xl font-semibold text-center">Contact</h3>
    <div class="flex justify-around">
        <a class="flex items-center hover:text-gray-300 transition" href="mailto:polar@utc.fr">
            <svg class="h-6 w-6" stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24"
                 aria-hidden="true" height="1em"
                 width="1em" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round"
                      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
            </svg>
            <p class="ml-2 font-mono">polar@utc.fr</p>
        </a>
        <a class="flex items-center hover:text-gray-300 transition" href="https://facebook.com/polar.utc.33"
           rel="noopener noreferrer" target="_blank">
            <svg class="h-6 w-6" stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 16 16"
                 height="1em" width="1em"
                 xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"></path>
            </svg>
            <p class="ml-2">Paul Ar</p>
        </a>
    </div>

    <h3 class="text-2xl font-semibold text-center">Où nous trouver</h3>
    <div class="flex justify-center mt-2">
        <a class="flex items-center hover:text-gray-300 transition" href="https://goo.gl/maps/q6soHUihaptyGQEr5">
            <svg class="h-6 w-6" stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 20 20" aria-hidden="true"
                 height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                      d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"
                      clip-rule="evenodd"></path>
            </svg>
            <p class="ml-2 text-center">Rue Roger Couttolenc, 60200 Compiègne<br/>2ème étage MDE</p>
        </a>
    </div>
</footer>
<script type="text/javascript">
    const header = document.querySelector('header');
    // hide footer on scroll down and show it on scroll up
    let lastScrollTop = 0;
    window.addEventListener('scroll', () => {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        if (scrollTop > lastScrollTop) {
            header.classList.add('-translate-y-full');
        } else {
            header.classList.remove('-translate-y-full');
        }
        lastScrollTop = scrollTop;
    });
</script>
</body>
</html>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/resources/views/components/layout.blade.php ENDPATH**/ ?>