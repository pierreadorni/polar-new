<?php echo e(money($amount, $currency, $convert)); ?>

<?php /**PATH /Users/pierreadorni/Documents/polar-new/vendor/akaunting/laravel-money/resources/views/components/money.blade.php ENDPATH**/ ?>