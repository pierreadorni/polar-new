<section class="bg-gray-100 py-12">
    <h3 class="text-2xl font-semibold text-center">L'équipe</h3>
    <ul class="flex flex-col md:flex-row mt-5 gap-12 w-screen justify-around">
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex flex-col items-center">
                        <img
                            src="/storage/<?php echo e($member->photo); ?>"
                            alt="<?php echo e($member->full_name); ?>"
                            class="w-24 h-24 rounded-full mx-auto object-center object-cover"
                        />
                    <div class="flex justify-center items-center h-8">
                        <?php echo e($member->first_name); ?> <?php echo e(strtoupper($member->last_name)); ?>

                    </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php /**PATH /Users/pierreadorni/Documents/polar-new/resources/views/components/team-section.blade.php ENDPATH**/ ?>