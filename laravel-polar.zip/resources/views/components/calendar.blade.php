<div id="calendar"></div>
<script>
    // on document ready
    document.onreadystatechange = () => {
        if (document.readyState === 'complete') {
            console.log('document ready')
            console.log(window.calendarVars);
            const {Calendar, timeGridPlugin} = window.calendarVars;

            let calendar = new Calendar(document.getElementById("calendar"), {
                    plugins: [timeGridPlugin],
                    initialView: 'agenda',
                    timeZone: 'UTC',
                    locale: 'en',
                    headerToolbar: {
                        left: '',
                        center: '',
                        right: ''
                    },
                    views: {
                        agenda: {
                            type: 'timeGridWeek',
                            duration: {
                                days: 7
                            },
                            firstDay: 3,
                            // hide day numbers
                            dayHeaderFormat: {
                                'weekday': 'long',
                            },
                            // start day at 8am
                            slotMinTime: '08:00:00',
                            // end day at 7pm
                            slotMaxTime: '19:00:00',
                            // show time as european format
                            slotLabelFormat: {
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: false
                            },
                            // hide all day events
                            allDaySlot: false,
                            nowIndicator: true,
                        }
                    },
                    navLinks: true,
                    editable: true,
                    selectable: false,
                    dayMaxEvents: true,
                    dateAlignment: 'week',
                    firstDay: 1,
                    // show length of events in day view
                    eventDisplay: 'block',
                }
            )
            calendar.render()
        }
    }
</script>
