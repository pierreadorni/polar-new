<section class="bg-gray-100 py-12">
    <h3 class="text-2xl font-semibold text-center">L'équipe</h3>
    <ul class="flex flex-col md:flex-row mt-5 gap-12 w-screen justify-around">
        @foreach($members as $member)
            <li class="flex flex-col items-center">
                        <img
                            src="/storage/{{ $member->photo }}"
                            alt="{{ $member->full_name }}"
                            class="w-24 h-24 rounded-full mx-auto object-center object-cover"
                        />
                    <div class="flex justify-center items-center h-8">
                        {{ $member->first_name }} {{ strtoupper($member->last_name) }}
                    </div>
            </li>
        @endforeach
</section>
