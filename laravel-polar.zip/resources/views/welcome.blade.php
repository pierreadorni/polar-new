<x-layout>
    <div class="h-screen bg-gray-200"></div>
    <x-products-services-section/>
    <x-about-section/>
    <x-team-section/>
</x-layout>
