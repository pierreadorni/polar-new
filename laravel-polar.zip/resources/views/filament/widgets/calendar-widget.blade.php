<x-filament::widget>
    <x-filament::card>
        {{-- Widget content --}}
    </x-filament::card>
</x-filament::widget>
