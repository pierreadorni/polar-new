<x-layout>
<div class="h-screen bg-gray-200"></div>
</x-layout>
